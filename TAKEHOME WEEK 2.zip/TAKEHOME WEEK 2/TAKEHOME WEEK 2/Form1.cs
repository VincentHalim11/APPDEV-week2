﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TAKEHOME_WEEK_2
{
    public partial class TebakKata : Form
    {
        private string jawaban;
        private string[] word = new string[5];
        private string clicked;
        int menang = 0;

        public TebakKata()
        {
            InitializeComponent();
        }

        private void btn_cek_Click(object sender, EventArgs e)
        {
            
            string box1 = box_nama1.Text;
            string box2 = box_nama2.Text;
            string box3 = box_nama3.Text;
            string box4 = box_nama4.Text;
            string box5 = box_nama5.Text;
            int jmlh_box1 = box1.Length;
            int jmlh_box2 = box2.Length;
            int jmlh_box3 = box3.Length;
            int jmlh_box4 = box4.Length;
            int jmlh_box5 = box5.Length;
            

            if(box1 == box2 || box1 == box3 || box1 == box4 || box1 == box5)
            {
                MessageBox.Show("Error bang, ada kata yang sama");
            }
            else if (box2 == box1 || box2 == box3 || box2 == box4 || box2 == box5)
            {
                MessageBox.Show("Error bang, ada kata yang sama");
            }
            else if (box3 == box1 || box3 == box2|| box3 == box4 || box3 == box5)
            {
                MessageBox.Show("Error bang, ada kata yang sama");
            }
            else if (box4 == box1 || box4 == box3 || box4 == box2 || box4 == box5)
            {
                MessageBox.Show("Error bang, ada kata yang sama");
            }
            else if (box5 == box1 || box5 == box3 || box5 == box4 || box5 == box2)
            {
                MessageBox.Show("Error bang, ada kata yang sama");
            }
            else
            {
                if (jmlh_box1 != 5 || jmlh_box2 != 5 || jmlh_box3 != 5 || jmlh_box4 != 5 || jmlh_box5 != 5)
                {
                    MessageBox.Show("Error bang, coba lagi");
                }
               
                else
                {
                    MessageBox.Show("Lanjut gan");
                    page2.Visible = true;


                    Random rnd = new Random();
                    int huruf = rnd.Next(1, 6);

                    if (huruf == 1)
                    {
                         jawaban = box_nama1.Text;
                    }
                    else if (huruf == 2)
                    {
                         jawaban = box_nama2.Text;
                    }
                    else if (huruf == 3)
                    {
                         jawaban = box_nama3.Text;
                    }
                    else if (huruf == 4)
                    {
                         jawaban = box_nama4.Text;
                    }
                    else if (huruf == 5)
                    {
                         jawaban = box_nama5.Text;
                    }
                    int i = 0;
                    foreach (char alphabet in jawaban)
                    {
                        string alfabet = alphabet.ToString();
                        word[i] = alfabet;
                        i++;
                    }

                    


                }
              
            }

            

        }

        private void HurufJawaban()
        {
            if(clicked == word[0])
            {
                jwbn1.Text = clicked;
                menang = menang+1;
            }
            if(clicked == word[1])
            {
                jwbn2.Text = clicked;
                menang = menang + 1;
            }
            if (clicked == word[2])
            {
                jwbn3.Text = clicked;
                menang = menang + 1;
            }
            if (clicked == word[3])
            {
                jwbn4.Text = clicked;
                menang = menang + 1;
            }
            if (clicked == word[4])
            {
                jwbn5.Text = clicked;
                menang = menang + 1;
            }

            if(menang == 5)
            {
                MessageBox.Show("Menang bang");
                Close();

            }
        }


        private void cheat_ans_Click(object sender, EventArgs e)
        {
            cheats.Text = jawaban;
            var cheating = MessageBox.Show("want to be a cheater","choose wisely", MessageBoxButtons.YesNo );
            if (cheating == DialogResult.Yes)
            {
                cheats.Visible = true;
            }
            
           
        }



        private void btn_q_Click(object sender, EventArgs e)
        {
            clicked = "q";
            HurufJawaban();
        }

        private void btn_w_Click(object sender, EventArgs e)
        {
            clicked = "w";
            HurufJawaban();
        }

        private void btn_e_Click(object sender, EventArgs e)
        {
            clicked = "e";
            HurufJawaban();
        }

        private void btn_r_Click(object sender, EventArgs e)
        {
            clicked = "r";
            HurufJawaban();
        }

        private void btn_t_Click(object sender, EventArgs e)
        {
            clicked = "t";
            HurufJawaban();
        }

        private void btn_y_Click(object sender, EventArgs e)
        {
            clicked = "y";
            HurufJawaban();
        }

        private void btn_u_Click(object sender, EventArgs e)
        {
            clicked = "u";
            HurufJawaban();
        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            clicked = "i";
            HurufJawaban();
        }

        private void btn_o_Click(object sender, EventArgs e)
        {
            clicked = "o";
            HurufJawaban();
        }

        private void btn_p_Click(object sender, EventArgs e)
        {
            clicked = "p";
            HurufJawaban();
        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            clicked = "a";
            HurufJawaban();
        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            clicked = "s";
            HurufJawaban();
        }

        private void btn_d_Click(object sender, EventArgs e)
        {
            clicked = "d";
            HurufJawaban();
        }

        private void btn_f_Click(object sender, EventArgs e)
        {
            clicked = "f";
            HurufJawaban();
        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            clicked = "g";
            HurufJawaban();
        }

        private void btn_h_Click(object sender, EventArgs e)
        {
            clicked = "h";
            HurufJawaban();
        }

        private void btn_j_Click(object sender, EventArgs e)
        {
            clicked = "j";
            HurufJawaban();
        }

        private void btn_k_Click(object sender, EventArgs e)
        {
            clicked = "k";
            HurufJawaban();
        }

        private void btn_l_Click(object sender, EventArgs e)
        {
            clicked = "l";
            HurufJawaban();
        }

        private void btn_z_Click(object sender, EventArgs e)
        {
            clicked = "z";
            HurufJawaban();
        }

        private void btn_x_Click(object sender, EventArgs e)
        {
            clicked = "x";
            HurufJawaban();
        }

        private void btn_c_Click(object sender, EventArgs e)
        {
            clicked = "c";
            HurufJawaban();
        }

        private void btn_v_Click(object sender, EventArgs e)
        {
            clicked = "v";
            HurufJawaban();
        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            clicked = "b";
            HurufJawaban();
        }

        private void btn_n_Click(object sender, EventArgs e)
        {
            clicked = "n";
            HurufJawaban();
        }

        private void btn_m_Click(object sender, EventArgs e)
        {
            clicked = "m";
            HurufJawaban();
        }
    }
}
