﻿namespace TAKEHOME_WEEK_2
{
    partial class TebakKata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box_nama1 = new System.Windows.Forms.TextBox();
            this.box_nama2 = new System.Windows.Forms.TextBox();
            this.box_nama3 = new System.Windows.Forms.TextBox();
            this.box_nama4 = new System.Windows.Forms.TextBox();
            this.box_nama5 = new System.Windows.Forms.TextBox();
            this.btn_cek = new System.Windows.Forms.Button();
            this.judul = new System.Windows.Forms.Label();
            this.page2 = new System.Windows.Forms.Panel();
            this.cheats = new System.Windows.Forms.Label();
            this.cheat_ans = new System.Windows.Forms.Button();
            this.jwbn5 = new System.Windows.Forms.Label();
            this.jwbn4 = new System.Windows.Forms.Label();
            this.jwbn3 = new System.Windows.Forms.Label();
            this.jwbn2 = new System.Windows.Forms.Label();
            this.jwbn1 = new System.Windows.Forms.Label();
            this.btn_m = new System.Windows.Forms.Button();
            this.btn_n = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.btn_v = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_x = new System.Windows.Forms.Button();
            this.btn_z = new System.Windows.Forms.Button();
            this.btn_l = new System.Windows.Forms.Button();
            this.btn_k = new System.Windows.Forms.Button();
            this.btn_j = new System.Windows.Forms.Button();
            this.btn_h = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_f = new System.Windows.Forms.Button();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_s = new System.Windows.Forms.Button();
            this.btn_a = new System.Windows.Forms.Button();
            this.btn_p = new System.Windows.Forms.Button();
            this.btn_o = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_u = new System.Windows.Forms.Button();
            this.btn_y = new System.Windows.Forms.Button();
            this.btn_t = new System.Windows.Forms.Button();
            this.btn_r = new System.Windows.Forms.Button();
            this.btn_e = new System.Windows.Forms.Button();
            this.btn_q = new System.Windows.Forms.Button();
            this.btn_w = new System.Windows.Forms.Button();
            this.pertama = new System.Windows.Forms.Label();
            this.kedua = new System.Windows.Forms.Label();
            this.ketiga = new System.Windows.Forms.Label();
            this.keempat = new System.Windows.Forms.Label();
            this.kelima = new System.Windows.Forms.Label();
            this.page2.SuspendLayout();
            this.SuspendLayout();
            // 
            // box_nama1
            // 
            this.box_nama1.Location = new System.Drawing.Point(137, 104);
            this.box_nama1.Name = "box_nama1";
            this.box_nama1.Size = new System.Drawing.Size(100, 20);
            this.box_nama1.TabIndex = 0;
            // 
            // box_nama2
            // 
            this.box_nama2.Location = new System.Drawing.Point(137, 130);
            this.box_nama2.Name = "box_nama2";
            this.box_nama2.Size = new System.Drawing.Size(100, 20);
            this.box_nama2.TabIndex = 3;
            // 
            // box_nama3
            // 
            this.box_nama3.Location = new System.Drawing.Point(137, 156);
            this.box_nama3.Name = "box_nama3";
            this.box_nama3.Size = new System.Drawing.Size(100, 20);
            this.box_nama3.TabIndex = 4;
            // 
            // box_nama4
            // 
            this.box_nama4.Location = new System.Drawing.Point(137, 182);
            this.box_nama4.Name = "box_nama4";
            this.box_nama4.Size = new System.Drawing.Size(100, 20);
            this.box_nama4.TabIndex = 5;
            // 
            // box_nama5
            // 
            this.box_nama5.Location = new System.Drawing.Point(137, 208);
            this.box_nama5.Name = "box_nama5";
            this.box_nama5.Size = new System.Drawing.Size(100, 20);
            this.box_nama5.TabIndex = 6;
            // 
            // btn_cek
            // 
            this.btn_cek.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_cek.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_cek.Location = new System.Drawing.Point(137, 234);
            this.btn_cek.Name = "btn_cek";
            this.btn_cek.Size = new System.Drawing.Size(72, 29);
            this.btn_cek.TabIndex = 7;
            this.btn_cek.Text = "play";
            this.btn_cek.UseVisualStyleBackColor = false;
            this.btn_cek.Click += new System.EventHandler(this.btn_cek_Click);
            // 
            // judul
            // 
            this.judul.AutoSize = true;
            this.judul.Font = new System.Drawing.Font("Kristen ITC", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.judul.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.judul.Location = new System.Drawing.Point(54, 26);
            this.judul.Name = "judul";
            this.judul.Size = new System.Drawing.Size(249, 51);
            this.judul.TabIndex = 8;
            this.judul.Text = "Input 5 Kata";
            // 
            // page2
            // 
            this.page2.Controls.Add(this.cheats);
            this.page2.Controls.Add(this.cheat_ans);
            this.page2.Controls.Add(this.jwbn5);
            this.page2.Controls.Add(this.jwbn4);
            this.page2.Controls.Add(this.jwbn3);
            this.page2.Controls.Add(this.jwbn2);
            this.page2.Controls.Add(this.jwbn1);
            this.page2.Controls.Add(this.btn_m);
            this.page2.Controls.Add(this.btn_n);
            this.page2.Controls.Add(this.btn_b);
            this.page2.Controls.Add(this.btn_v);
            this.page2.Controls.Add(this.btn_c);
            this.page2.Controls.Add(this.btn_x);
            this.page2.Controls.Add(this.btn_z);
            this.page2.Controls.Add(this.btn_l);
            this.page2.Controls.Add(this.btn_k);
            this.page2.Controls.Add(this.btn_j);
            this.page2.Controls.Add(this.btn_h);
            this.page2.Controls.Add(this.btn_g);
            this.page2.Controls.Add(this.btn_f);
            this.page2.Controls.Add(this.btn_d);
            this.page2.Controls.Add(this.btn_s);
            this.page2.Controls.Add(this.btn_a);
            this.page2.Controls.Add(this.btn_p);
            this.page2.Controls.Add(this.btn_o);
            this.page2.Controls.Add(this.btn_i);
            this.page2.Controls.Add(this.btn_u);
            this.page2.Controls.Add(this.btn_y);
            this.page2.Controls.Add(this.btn_t);
            this.page2.Controls.Add(this.btn_r);
            this.page2.Controls.Add(this.btn_e);
            this.page2.Controls.Add(this.btn_q);
            this.page2.Controls.Add(this.btn_w);
            this.page2.Location = new System.Drawing.Point(2, 2);
            this.page2.Name = "page2";
            this.page2.Size = new System.Drawing.Size(795, 398);
            this.page2.TabIndex = 9;
            this.page2.Visible = false;
            // 
            // cheats
            // 
            this.cheats.AutoSize = true;
            this.cheats.Location = new System.Drawing.Point(685, 74);
            this.cheats.Name = "cheats";
            this.cheats.Size = new System.Drawing.Size(40, 13);
            this.cheats.TabIndex = 32;
            this.cheats.Text = "curang";
            this.cheats.Visible = false;
            // 
            // cheat_ans
            // 
            this.cheat_ans.Location = new System.Drawing.Point(664, 39);
            this.cheat_ans.Name = "cheat_ans";
            this.cheat_ans.Size = new System.Drawing.Size(80, 21);
            this.cheat_ans.TabIndex = 31;
            this.cheat_ans.Text = "Cheat";
            this.cheat_ans.UseVisualStyleBackColor = true;
            this.cheat_ans.Click += new System.EventHandler(this.cheat_ans_Click);
            // 
            // jwbn5
            // 
            this.jwbn5.AutoSize = true;
            this.jwbn5.Cursor = System.Windows.Forms.Cursors.Default;
            this.jwbn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jwbn5.Location = new System.Drawing.Point(500, 60);
            this.jwbn5.Name = "jwbn5";
            this.jwbn5.Size = new System.Drawing.Size(67, 73);
            this.jwbn5.TabIndex = 30;
            this.jwbn5.Text = "_";
            // 
            // jwbn4
            // 
            this.jwbn4.AutoSize = true;
            this.jwbn4.Cursor = System.Windows.Forms.Cursors.Default;
            this.jwbn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jwbn4.Location = new System.Drawing.Point(427, 60);
            this.jwbn4.Name = "jwbn4";
            this.jwbn4.Size = new System.Drawing.Size(67, 73);
            this.jwbn4.TabIndex = 29;
            this.jwbn4.Text = "_";
            // 
            // jwbn3
            // 
            this.jwbn3.AutoSize = true;
            this.jwbn3.Cursor = System.Windows.Forms.Cursors.Default;
            this.jwbn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jwbn3.Location = new System.Drawing.Point(352, 60);
            this.jwbn3.Name = "jwbn3";
            this.jwbn3.Size = new System.Drawing.Size(67, 73);
            this.jwbn3.TabIndex = 28;
            this.jwbn3.Text = "_";
            // 
            // jwbn2
            // 
            this.jwbn2.AutoSize = true;
            this.jwbn2.Cursor = System.Windows.Forms.Cursors.Default;
            this.jwbn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jwbn2.Location = new System.Drawing.Point(277, 60);
            this.jwbn2.Name = "jwbn2";
            this.jwbn2.Size = new System.Drawing.Size(67, 73);
            this.jwbn2.TabIndex = 27;
            this.jwbn2.Text = "_";
            // 
            // jwbn1
            // 
            this.jwbn1.AutoSize = true;
            this.jwbn1.Cursor = System.Windows.Forms.Cursors.Default;
            this.jwbn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jwbn1.Location = new System.Drawing.Point(212, 60);
            this.jwbn1.Name = "jwbn1";
            this.jwbn1.Size = new System.Drawing.Size(67, 73);
            this.jwbn1.TabIndex = 26;
            this.jwbn1.Text = "_";
            // 
            // btn_m
            // 
            this.btn_m.Location = new System.Drawing.Point(543, 280);
            this.btn_m.Name = "btn_m";
            this.btn_m.Size = new System.Drawing.Size(65, 43);
            this.btn_m.TabIndex = 25;
            this.btn_m.Text = "M";
            this.btn_m.UseVisualStyleBackColor = true;
            this.btn_m.Click += new System.EventHandler(this.btn_m_Click);
            // 
            // btn_n
            // 
            this.btn_n.Location = new System.Drawing.Point(466, 280);
            this.btn_n.Name = "btn_n";
            this.btn_n.Size = new System.Drawing.Size(67, 43);
            this.btn_n.TabIndex = 24;
            this.btn_n.Text = "N";
            this.btn_n.UseVisualStyleBackColor = true;
            this.btn_n.Click += new System.EventHandler(this.btn_n_Click);
            // 
            // btn_b
            // 
            this.btn_b.Location = new System.Drawing.Point(400, 280);
            this.btn_b.Name = "btn_b";
            this.btn_b.Size = new System.Drawing.Size(60, 43);
            this.btn_b.TabIndex = 23;
            this.btn_b.Text = "B";
            this.btn_b.UseVisualStyleBackColor = true;
            this.btn_b.Click += new System.EventHandler(this.btn_b_Click);
            // 
            // btn_v
            // 
            this.btn_v.Location = new System.Drawing.Point(325, 281);
            this.btn_v.Name = "btn_v";
            this.btn_v.Size = new System.Drawing.Size(69, 43);
            this.btn_v.TabIndex = 22;
            this.btn_v.Text = "V";
            this.btn_v.UseVisualStyleBackColor = true;
            this.btn_v.Click += new System.EventHandler(this.btn_v_Click);
            // 
            // btn_c
            // 
            this.btn_c.Location = new System.Drawing.Point(262, 281);
            this.btn_c.Name = "btn_c";
            this.btn_c.Size = new System.Drawing.Size(57, 43);
            this.btn_c.TabIndex = 21;
            this.btn_c.Text = "C";
            this.btn_c.UseVisualStyleBackColor = true;
            this.btn_c.Click += new System.EventHandler(this.btn_c_Click);
            // 
            // btn_x
            // 
            this.btn_x.Location = new System.Drawing.Point(199, 280);
            this.btn_x.Name = "btn_x";
            this.btn_x.Size = new System.Drawing.Size(57, 43);
            this.btn_x.TabIndex = 20;
            this.btn_x.Text = "X";
            this.btn_x.UseVisualStyleBackColor = true;
            this.btn_x.Click += new System.EventHandler(this.btn_x_Click);
            // 
            // btn_z
            // 
            this.btn_z.Location = new System.Drawing.Point(125, 281);
            this.btn_z.Name = "btn_z";
            this.btn_z.Size = new System.Drawing.Size(68, 43);
            this.btn_z.TabIndex = 19;
            this.btn_z.Text = "Z";
            this.btn_z.UseVisualStyleBackColor = true;
            this.btn_z.Click += new System.EventHandler(this.btn_z_Click);
            // 
            // btn_l
            // 
            this.btn_l.Location = new System.Drawing.Point(624, 232);
            this.btn_l.Name = "btn_l";
            this.btn_l.Size = new System.Drawing.Size(64, 43);
            this.btn_l.TabIndex = 18;
            this.btn_l.Text = "L";
            this.btn_l.UseVisualStyleBackColor = true;
            this.btn_l.Click += new System.EventHandler(this.btn_l_Click);
            // 
            // btn_k
            // 
            this.btn_k.Location = new System.Drawing.Point(552, 232);
            this.btn_k.Name = "btn_k";
            this.btn_k.Size = new System.Drawing.Size(66, 43);
            this.btn_k.TabIndex = 17;
            this.btn_k.Text = "K";
            this.btn_k.UseVisualStyleBackColor = true;
            this.btn_k.Click += new System.EventHandler(this.btn_k_Click);
            // 
            // btn_j
            // 
            this.btn_j.Location = new System.Drawing.Point(489, 232);
            this.btn_j.Name = "btn_j";
            this.btn_j.Size = new System.Drawing.Size(57, 43);
            this.btn_j.TabIndex = 16;
            this.btn_j.Text = "J";
            this.btn_j.UseVisualStyleBackColor = true;
            this.btn_j.Click += new System.EventHandler(this.btn_j_Click);
            // 
            // btn_h
            // 
            this.btn_h.Location = new System.Drawing.Point(423, 232);
            this.btn_h.Name = "btn_h";
            this.btn_h.Size = new System.Drawing.Size(60, 43);
            this.btn_h.TabIndex = 15;
            this.btn_h.Text = "H";
            this.btn_h.UseVisualStyleBackColor = true;
            this.btn_h.Click += new System.EventHandler(this.btn_h_Click);
            // 
            // btn_g
            // 
            this.btn_g.Location = new System.Drawing.Point(354, 232);
            this.btn_g.Name = "btn_g";
            this.btn_g.Size = new System.Drawing.Size(63, 43);
            this.btn_g.TabIndex = 14;
            this.btn_g.Text = "G";
            this.btn_g.UseVisualStyleBackColor = true;
            this.btn_g.Click += new System.EventHandler(this.btn_g_Click);
            // 
            // btn_f
            // 
            this.btn_f.Location = new System.Drawing.Point(291, 232);
            this.btn_f.Name = "btn_f";
            this.btn_f.Size = new System.Drawing.Size(57, 43);
            this.btn_f.TabIndex = 13;
            this.btn_f.Text = "F";
            this.btn_f.UseVisualStyleBackColor = true;
            this.btn_f.Click += new System.EventHandler(this.btn_f_Click);
            // 
            // btn_d
            // 
            this.btn_d.Location = new System.Drawing.Point(228, 231);
            this.btn_d.Name = "btn_d";
            this.btn_d.Size = new System.Drawing.Size(57, 43);
            this.btn_d.TabIndex = 12;
            this.btn_d.Text = "D";
            this.btn_d.UseVisualStyleBackColor = true;
            this.btn_d.Click += new System.EventHandler(this.btn_d_Click);
            // 
            // btn_s
            // 
            this.btn_s.Location = new System.Drawing.Point(165, 232);
            this.btn_s.Name = "btn_s";
            this.btn_s.Size = new System.Drawing.Size(57, 43);
            this.btn_s.TabIndex = 11;
            this.btn_s.Text = "S";
            this.btn_s.UseVisualStyleBackColor = true;
            this.btn_s.Click += new System.EventHandler(this.btn_s_Click);
            // 
            // btn_a
            // 
            this.btn_a.Location = new System.Drawing.Point(97, 232);
            this.btn_a.Name = "btn_a";
            this.btn_a.Size = new System.Drawing.Size(62, 43);
            this.btn_a.TabIndex = 10;
            this.btn_a.Text = "A";
            this.btn_a.UseVisualStyleBackColor = true;
            this.btn_a.Click += new System.EventHandler(this.btn_a_Click);
            // 
            // btn_p
            // 
            this.btn_p.Location = new System.Drawing.Point(664, 182);
            this.btn_p.Name = "btn_p";
            this.btn_p.Size = new System.Drawing.Size(67, 43);
            this.btn_p.TabIndex = 9;
            this.btn_p.Text = "P";
            this.btn_p.UseVisualStyleBackColor = true;
            this.btn_p.Click += new System.EventHandler(this.btn_p_Click);
            // 
            // btn_o
            // 
            this.btn_o.Location = new System.Drawing.Point(602, 182);
            this.btn_o.Name = "btn_o";
            this.btn_o.Size = new System.Drawing.Size(56, 43);
            this.btn_o.TabIndex = 8;
            this.btn_o.Text = "O";
            this.btn_o.UseVisualStyleBackColor = true;
            this.btn_o.Click += new System.EventHandler(this.btn_o_Click);
            // 
            // btn_i
            // 
            this.btn_i.Location = new System.Drawing.Point(541, 182);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(55, 43);
            this.btn_i.TabIndex = 7;
            this.btn_i.Text = "I";
            this.btn_i.UseVisualStyleBackColor = true;
            this.btn_i.Click += new System.EventHandler(this.btn_i_Click);
            // 
            // btn_u
            // 
            this.btn_u.Location = new System.Drawing.Point(473, 182);
            this.btn_u.Name = "btn_u";
            this.btn_u.Size = new System.Drawing.Size(60, 43);
            this.btn_u.TabIndex = 6;
            this.btn_u.Text = "U";
            this.btn_u.UseVisualStyleBackColor = true;
            this.btn_u.Click += new System.EventHandler(this.btn_u_Click);
            // 
            // btn_y
            // 
            this.btn_y.Location = new System.Drawing.Point(403, 182);
            this.btn_y.Name = "btn_y";
            this.btn_y.Size = new System.Drawing.Size(64, 43);
            this.btn_y.TabIndex = 5;
            this.btn_y.Text = "Y";
            this.btn_y.UseVisualStyleBackColor = true;
            this.btn_y.Click += new System.EventHandler(this.btn_y_Click);
            // 
            // btn_t
            // 
            this.btn_t.Location = new System.Drawing.Point(340, 182);
            this.btn_t.Name = "btn_t";
            this.btn_t.Size = new System.Drawing.Size(54, 43);
            this.btn_t.TabIndex = 4;
            this.btn_t.Text = "T";
            this.btn_t.UseVisualStyleBackColor = true;
            this.btn_t.Click += new System.EventHandler(this.btn_t_Click);
            // 
            // btn_r
            // 
            this.btn_r.Location = new System.Drawing.Point(279, 182);
            this.btn_r.Name = "btn_r";
            this.btn_r.Size = new System.Drawing.Size(55, 43);
            this.btn_r.TabIndex = 3;
            this.btn_r.Text = "R";
            this.btn_r.UseVisualStyleBackColor = true;
            this.btn_r.Click += new System.EventHandler(this.btn_r_Click);
            // 
            // btn_e
            // 
            this.btn_e.Location = new System.Drawing.Point(217, 182);
            this.btn_e.Name = "btn_e";
            this.btn_e.Size = new System.Drawing.Size(56, 43);
            this.btn_e.TabIndex = 2;
            this.btn_e.Text = "E";
            this.btn_e.UseVisualStyleBackColor = true;
            this.btn_e.Click += new System.EventHandler(this.btn_e_Click);
            // 
            // btn_q
            // 
            this.btn_q.Location = new System.Drawing.Point(82, 182);
            this.btn_q.Name = "btn_q";
            this.btn_q.Size = new System.Drawing.Size(67, 43);
            this.btn_q.TabIndex = 1;
            this.btn_q.Text = "Q";
            this.btn_q.UseVisualStyleBackColor = true;
            this.btn_q.Click += new System.EventHandler(this.btn_q_Click);
            // 
            // btn_w
            // 
            this.btn_w.Location = new System.Drawing.Point(155, 182);
            this.btn_w.Name = "btn_w";
            this.btn_w.Size = new System.Drawing.Size(56, 43);
            this.btn_w.TabIndex = 0;
            this.btn_w.Text = "W";
            this.btn_w.UseVisualStyleBackColor = true;
            this.btn_w.Click += new System.EventHandler(this.btn_w_Click);
            // 
            // pertama
            // 
            this.pertama.AutoSize = true;
            this.pertama.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pertama.Location = new System.Drawing.Point(59, 105);
            this.pertama.Name = "pertama";
            this.pertama.Size = new System.Drawing.Size(69, 20);
            this.pertama.TabIndex = 10;
            this.pertama.Text = "KATA 1";
            // 
            // kedua
            // 
            this.kedua.AutoSize = true;
            this.kedua.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kedua.Location = new System.Drawing.Point(59, 128);
            this.kedua.Name = "kedua";
            this.kedua.Size = new System.Drawing.Size(69, 20);
            this.kedua.TabIndex = 11;
            this.kedua.Text = "KATA 2";
            // 
            // ketiga
            // 
            this.ketiga.AutoSize = true;
            this.ketiga.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ketiga.Location = new System.Drawing.Point(59, 154);
            this.ketiga.Name = "ketiga";
            this.ketiga.Size = new System.Drawing.Size(69, 20);
            this.ketiga.TabIndex = 12;
            this.ketiga.Text = "KATA 3";
            // 
            // keempat
            // 
            this.keempat.AutoSize = true;
            this.keempat.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keempat.Location = new System.Drawing.Point(59, 180);
            this.keempat.Name = "keempat";
            this.keempat.Size = new System.Drawing.Size(69, 20);
            this.keempat.TabIndex = 13;
            this.keempat.Text = "KATA 4";
            // 
            // kelima
            // 
            this.kelima.AutoSize = true;
            this.kelima.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kelima.Location = new System.Drawing.Point(59, 206);
            this.kelima.Name = "kelima";
            this.kelima.Size = new System.Drawing.Size(69, 20);
            this.kelima.TabIndex = 14;
            this.kelima.Text = "KATA 5";
            // 
            // TebakKata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.page2);
            this.Controls.Add(this.judul);
            this.Controls.Add(this.btn_cek);
            this.Controls.Add(this.box_nama5);
            this.Controls.Add(this.box_nama4);
            this.Controls.Add(this.box_nama3);
            this.Controls.Add(this.box_nama2);
            this.Controls.Add(this.box_nama1);
            this.Controls.Add(this.kelima);
            this.Controls.Add(this.keempat);
            this.Controls.Add(this.ketiga);
            this.Controls.Add(this.kedua);
            this.Controls.Add(this.pertama);
            this.Name = "TebakKata";
            this.Text = "Form1";
            this.page2.ResumeLayout(false);
            this.page2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox box_nama1;
        private System.Windows.Forms.TextBox box_nama2;
        private System.Windows.Forms.TextBox box_nama3;
        private System.Windows.Forms.TextBox box_nama4;
        private System.Windows.Forms.TextBox box_nama5;
        private System.Windows.Forms.Button btn_cek;
        private System.Windows.Forms.Label judul;
        private System.Windows.Forms.Panel page2;
        private System.Windows.Forms.Label pertama;
        private System.Windows.Forms.Label kedua;
        private System.Windows.Forms.Label ketiga;
        private System.Windows.Forms.Label keempat;
        private System.Windows.Forms.Label kelima;
        private System.Windows.Forms.Button btn_w;
        private System.Windows.Forms.Button btn_p;
        private System.Windows.Forms.Button btn_o;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_u;
        private System.Windows.Forms.Button btn_y;
        private System.Windows.Forms.Button btn_t;
        private System.Windows.Forms.Button btn_r;
        private System.Windows.Forms.Button btn_e;
        private System.Windows.Forms.Button btn_q;
        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.Button btn_a;
        private System.Windows.Forms.Button btn_l;
        private System.Windows.Forms.Button btn_k;
        private System.Windows.Forms.Button btn_j;
        private System.Windows.Forms.Button btn_h;
        private System.Windows.Forms.Button btn_g;
        private System.Windows.Forms.Button btn_f;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_x;
        private System.Windows.Forms.Button btn_z;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_m;
        private System.Windows.Forms.Button btn_n;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Button btn_v;
        private System.Windows.Forms.Label jwbn3;
        private System.Windows.Forms.Label jwbn2;
        private System.Windows.Forms.Label jwbn1;
        private System.Windows.Forms.Label jwbn5;
        private System.Windows.Forms.Label jwbn4;
        private System.Windows.Forms.Button cheat_ans;
        private System.Windows.Forms.Label cheats;
    }
}

